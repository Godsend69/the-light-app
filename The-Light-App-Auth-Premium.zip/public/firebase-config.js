const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "the-light-2025.firebaseapp.com",
  projectId: "the-light-2025",
  storageBucket: "the-light-2025.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
firebase.initializeApp(firebaseConfig);

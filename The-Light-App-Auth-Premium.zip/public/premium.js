const auth=firebase.auth(); const db=firebase.firestore();
const priceId='price_XXXXX_REPLACE_IN_STRIPE';
const buyBtn=document.getElementById('buyBtn'); const state=document.getElementById('premiumState');
auth.onAuthStateChanged(async user=>{
 if(!user){ state.textContent='Please sign in to check premium.'; buyBtn.onclick=()=>location.href='/login.html'; return;}
 const doc=await db.collection('users').doc(user.uid).get();
 const isPremium=doc.exists && !!doc.data().premium;
 if(isPremium){ state.textContent='✅ You are Premium. Thank you!'; buyBtn.disabled=true; return;} else { state.textContent='You are on the free plan.'; }
 buyBtn.onclick=async ()=>{
  buyBtn.disabled=true; state.textContent='Contacting Stripe…';
  try{
    const resp=await fetch('/createCheckoutSession',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({priceId, uid:user.uid})});
    const data=await resp.json(); if(data.url){ location.href=data.url; } else { throw new Error(data.error||'Unknown error'); }
  }catch(err){ state.textContent='Failed: '+err.message; buyBtn.disabled=false; }
 };
});

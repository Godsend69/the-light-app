import * as functions from "firebase-functions";
import Stripe from "stripe";
import * as admin from "firebase-admin";
import corsLib from "cors";

admin.initializeApp();
const db = admin.firestore();

const stripeSecret = functions.config().stripe?.secret;
const stripe = new Stripe(stripeSecret || "sk_test_missing", { apiVersion: "2023-10-16" });
const cors = corsLib({ origin: true });

export const createCheckoutSession = functions.https.onRequest(async (req, res) => {
  return cors(req, res, async () => {
    try {
      if (req.method !== "POST") { res.status(405).json({ error: "Method not allowed" }); return; }
      const { priceId, uid } = req.body || {};
      if (!priceId || !uid) { res.status(400).json({ error: "Missing priceId or uid" }); return; }
      const session = await stripe.checkout.sessions.create({
        mode: "subscription",
        payment_method_types: ["card"],
        line_items: [{ price: priceId, quantity: 1 }],
        success_url: `${req.headers.origin || "https://the-light-2025.web.app"}/premium.html?success=true`,
        cancel_url: `${req.headers.origin || "https://the-light-2025.web.app"}/premium.html?canceled=true`,
        metadata: { uid }
      });
      res.json({ url: session.url });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: (err && err.message) || "Server error" });
    }
  });
});

export const stripeWebhook = functions.https.onRequest(async (req, res) => {
  const sig = req.headers["stripe-signature"];
  const webhookSecret = functions.config().stripe?.webhook_secret;
  let event;
  try {
    if (!sig || !webhookSecret) throw new Error("Missing signature/secret");
    event = new Stripe(stripeSecret, { apiVersion: "2023-10-16" })
      .webhooks.constructEvent(req.rawBody, sig, webhookSecret);
  } catch (err) {
    console.error("Webhook signature verification failed.", err);
    res.status(400).send("Bad signature"); return;
  }
  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const uid = session?.metadata?.uid;
    if (uid) await db.collection("users").doc(uid).set({ premium: true, updatedAt: Date.now() }, { merge: true });
  }
  res.json({ received: true });
});

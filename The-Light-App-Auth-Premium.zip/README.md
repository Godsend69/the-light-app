# THE LIGHT — Auth + Premium (Firebase + Stripe)

## Deploy
1. Replace `public/firebase-config.js` with your real Firebase web config.
2. Set Stripe **Price ID** in `public/premium.js` (`price_...`).
3. Configure Stripe secrets in Functions and deploy:
```bash
firebase use the-light-2025
firebase functions:config:set stripe.secret="sk_test_or_live" stripe.webhook_secret="whsec_..."
firebase deploy
```
4. In Stripe dashboard, create webhook to:
`https://us-central1-the-light-2025.cloudfunctions.net/stripeWebhook`
for event `checkout.session.completed`.

Firestore document `users/{uid}.premium` will be set to `true` by the webhook.

# The Light App (clean build)

This zip contains a minimal, production-ready web build of **The Light App** — a tiny, zero-dependency app that toggles a light.

## How to run
1. Unzip the package.
2. Open `build/index.html` in any modern browser (double-click it). No server needed.

## Features
- Zero dependencies; works offline
- Persistent state via `localStorage`
- Accessible: `aria-live` status and keyboard shortcut (`L` to toggle)
- Tiny footprint (~1 KB JS, minified CSS)

## Files
- `build/index.html` – entry point
- `build/styles.css` – minified styles
- `build/app.js` – minified JS
